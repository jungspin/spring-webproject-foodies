package com.example.foodies.model;

public enum age {
age_10,age_20,age_30,age_40,age_more
}
