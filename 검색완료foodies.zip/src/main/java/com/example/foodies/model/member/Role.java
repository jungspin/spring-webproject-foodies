package com.example.foodies.model.member;

public enum Role {
ROLE_Manager, ROLE_Member
}
