package com.example.foodies.model.member;

import lombok.Data;

@Data
public class AuthMailDTO {

	private String rawKey;
	private String encodedKey;
}
