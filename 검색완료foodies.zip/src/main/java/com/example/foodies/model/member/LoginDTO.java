package com.example.foodies.model.member;

import lombok.Data;

@Data
public class LoginDTO {
	
	private String username;
	private String password;

}
