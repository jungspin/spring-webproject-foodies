package com.example.foodies.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.foodies.model.Restaurant;

public interface BoardRepository extends JpaRepository<Restaurant, Long> {

	//
	 //@Query("select r from restaurant r where r.addr1 like %:?1% ") 
	// List<Restaurant> searchBy(@Param("keyword") String keyword);
	
	/*
	 * @Query("select r from restaurant r where r.main_title like %?1%")
	 * List<Restaurant> findByMainTitle(String keyword);
	 */
	//@Query("select r from restaurant r where r.addr1 like %:keyword% or r.cntct_tel like %:keyword% or r.itemcntnts like %:keyword% or r.main_title like %:keyword% or r.rprsntv_menu like %:keyword%") 
	
	 
	  List<Restaurant>findByMainTitleContaining(String keyword); 	 
	  List<Restaurant>findByAddr1Containing(String keyword);
	  List<Restaurant>findByRprsntvMenuContaining(String keyword);
	  List<Restaurant>findByItemcntntsContaining(String keyword);
	 

	
	
}
