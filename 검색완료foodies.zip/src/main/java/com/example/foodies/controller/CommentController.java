package com.example.foodies.controller;

public class CommentController {

}
